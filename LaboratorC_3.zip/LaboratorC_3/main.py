from utils import criptare, decriptare

alfabet = "AĂÂBCDEFGHIÎJKLMNOPQRSȘTȚUVWXYZ"
while True:
    print("\n-------------------------------")
    print("\nMenu:")
    print("\n1)Criptare")
    print("2)Decriptare")
    print("0)Iesire")
    print("\n-------------------------------")
    choice = int(input("\n"))
    match choice:
        case 1:
            while True:
                print("\n-------------------------------")
                mesaj = input("\nIntrodu mesajul: ").upper()
                mesaj = mesaj.replace(" ", "")
                valid = True
                for litera in mesaj:
                    if litera not in alfabet:
                        print("\n-------------------------------")
                        print(
                            "\nTextul contine unul sau mai multe caractere ilegale folositi litere A - Z sau a-z"
                        )
                        valid = False
                        break
                if valid == True:
                    break
            while True:
                print("\n-------------------------------")
                cheia = input("\nIntrodu cheia: ").upper()
                cheia = cheia.replace(" ", "")
                if len(cheia) >= 7:
                    break
                else:
                    print("\n-------------------------------")
                    print("\nCheia e prea scurta!")
                for litera in cheia:
                    if litera not in alfabet:
                        print("\n-------------------------------")
                        print(
                            "\nTextul contine unul sau mai multe caractere ilegale folositi litere A - Z sau a-z"
                        )
                        valid = False
                        break
                if valid == True:
                    break            
            criptograma = criptare(mesaj,cheia,alfabet)
            print("\nMesajul criptat: " + criptograma)
            print("\n-------------------------------")
        case 2:
            while True:
                print("\n-------------------------------")
                mesaj = input("\nIntrodu mesajul: ").upper()
                mesaj = mesaj.replace(" ", "")
                valid = True
                for litera in mesaj:
                    if litera not in alfabet:
                        print("\n-------------------------------")
                        print(
                            "\nTextul contine unul sau mai multe caractere ilegale folositi litere A - Z sau a-z"
                        )
                        valid = False
                        break
                if valid == True:
                    break
            while True:
                print("\n-------------------------------")
                cheia = input("\nIntrodu cheia: ").upper()
                cheia = cheia.replace(" ", "")
                if len(cheia) >= 7:
                    break
                for litera in cheia:
                    if litera not in alfabet:
                        print("\n-------------------------------")
                        print(
                            "\nTextul contine unul sau mai multe caractere ilegale folositi litere A - Z sau a-z"
                        )
                        valid = False
                        break
                if valid == True:
                    break       
                else:
                    print("\n-------------------------------")
                    print("\nCheia e prea scurta!")            
            decriptat = decriptare(mesaj,cheia,alfabet)
            print("\n-------------------------------")
            print("\nMesajul criptat: " + decriptat)
        case 0:
                print("\n-------------------------------")
                break 
        case _:
              print("\n-------------------------------")
              print("\nAlege o optiune din menu!")    
    