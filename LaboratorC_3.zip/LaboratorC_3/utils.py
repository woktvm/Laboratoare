def criptare (mesaj,cheia,alfabet):
    result = ""
    i=0
    while len(mesaj) > len(cheia):
        cheia +=cheia
    for litera in mesaj:
        placeholder = cheia[i]
        lcriptata = (alfabet.find(litera) + alfabet.find(placeholder)) % len(alfabet)
        result+=alfabet[lcriptata]
        i+=1
    return result

def decriptare (criptograma,cheia,alfabet):
    result = ""
    i=0
    while len(criptograma) > len(cheia):
        cheia +=cheia
    for litera in criptograma:
        placeholder = cheia[i]
        ldecriptata = (alfabet.find(litera) - alfabet.find(placeholder)) % len(alfabet)
        result+=alfabet[ldecriptata]
        i+=1
    return result


